#pragma once
#include <Arduino.h>

// Defines Variables
#define BUTTON1 DDB0
#define BUTTON2 DDB1

//Function Prototypes
void PCINT0_init(void);
void Timer1_init(void);