#pragma once
#include<Arduino.h>
#define ARRAY_SIZE_DECIMAL 10

void displyValue(byte value);

 