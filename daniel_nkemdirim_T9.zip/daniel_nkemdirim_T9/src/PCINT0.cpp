#include "PCINT0.h"

void PCINT0_init()
{
    DDRB &= ~(1 << BUTTON1) & ~(1 << BUTTON2);
    PORTB |= (1 << BUTTON1) | (1 << BUTTON2);

    PCICR |= (1 << PCIE0);
    PCMSK0 |= (1 << PCINT0) | (1 << PCINT1);
    sei();
}

void Timer1_init()
{
    TCCR1B |= (1 << CS12);
    TCNT1 = 34285;
    TIMSK1 |= (1 << TOIE1);
    sei();
}
