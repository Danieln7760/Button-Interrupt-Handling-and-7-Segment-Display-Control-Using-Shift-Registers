#include"ShiftReg.h"

void init_shift(byte dataPin, byte clockPin, byte latchPin)
{
    DDRD |= (1<<dataPin) | (1<<latchPin) | (1<<clockPin);
}

void myShiftOut(byte dataPin, byte clockPin, byte bitOrder, byte val)
{
  byte i;
  for (i = 0; i < 8; i++)  
  {
      if (bitOrder == LSBFIRST) {
        if((val & 1)) 
        {
          PORTD|= (1<<dataPin); 
        }
        else
        {
          PORTD&= ~(1<<dataPin); 
        }   
        val >>= 1; 
      } else {
        if((val & 128) != 0)
        {
          PORTD|= (1<<dataPin);
        }
        else
        {
          PORTD&= ~(1<<dataPin);
        }   
        val <<= 1; 
      }
      PORTD |= (1<<clockPin);
      PORTD &= ~(1<<clockPin);
  }
}
